package PrimerParcial.Mediator;


public interface Chat {

     void send(String msg, Player playerDestination, Player playerFrom);
}
