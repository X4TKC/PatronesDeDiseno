package PrimerParcial.Singleton;

public class Client {
    public static void main(String[] args){
        Student s2= new Student("Pedro");
        Student s1= new Student("Pedro2");
        Student s3= new Student("Pedro3");

        s2.payTuition(1500);
        s1.payTuition(1200);
        s3.payTuition(500);
        Account acc= Account.getInstance();
        System.out.println(acc.getTuition().get(1).getNombre());
        System.out.println(acc.getTuition().get(0).getNombre());
        System.out.println(acc.getTuition().get(2).getNombre());

    }
}
