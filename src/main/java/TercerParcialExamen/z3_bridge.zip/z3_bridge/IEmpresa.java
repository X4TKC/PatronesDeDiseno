package z3_bridge;

public interface IEmpresa {
	public void tipoDeEnvio();
}
