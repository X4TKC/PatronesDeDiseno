package z3_bridge;

public interface IPaquete {
	public double enviarPaquete();
}
