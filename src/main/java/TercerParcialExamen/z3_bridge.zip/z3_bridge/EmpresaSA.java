package z3_bridge;

public class EmpresaSA implements IEmpresa {
	private IPaquete paquete;

	public EmpresaSA(IPaquete paquete) {
		super();
		this.paquete = paquete;
	}

	@Override
	public void tipoDeEnvio() {
		System.out.println("--------------------------------------------");
		System.out.println("Empresa SA");
		System.out.println("El monto que se tiene que pagar es: "+this.paquete.enviarPaquete());

	}

}
