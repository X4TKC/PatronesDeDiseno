package Adapter2;

public interface IAuto {
    void cargar(int var1);

    int estadoElectricidad();
}
