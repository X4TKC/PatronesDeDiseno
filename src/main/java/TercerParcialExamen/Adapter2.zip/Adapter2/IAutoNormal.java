package Adapter2;

public interface IAutoNormal {
    void setLlenarGasolina(int var1);

    int estadoCombustible();
}
