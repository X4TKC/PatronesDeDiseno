package proxy;

public interface ITarjeta {
	public void transaccion();
}
