package proxy;

import proxy.Client.Monedas;

public class Request {
	private int montoActual;
	private int montoCompra;
	private Monedas moneda;
	
	public Request(int montoActual, int montoCompra, Monedas moneda) {
		super();
		this.montoActual = montoActual;
		this.montoCompra = montoCompra;
		this.moneda = moneda;
	}

	public int getMontoActual() {
		return montoActual;
	}

	public void setMontoActual(int montoActual) {
		this.montoActual = montoActual;
	}

	public int getMontoCompra() {
		return montoCompra;
	}

	public void setMontoCompra(int montoCompra) {
		this.montoCompra = montoCompra;
	}

	public Monedas getMoneda() {
		return moneda;
	}

	public void setMoneda(Monedas moneda) {
		this.moneda = moneda;
	}
	
	
	
}
