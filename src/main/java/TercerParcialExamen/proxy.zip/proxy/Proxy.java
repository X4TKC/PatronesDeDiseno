package proxy;

public class Proxy implements ITarjeta{

	private Request request;
	private Transaccion transaccion = null;
		
	public Proxy(Request request) {
		this.request = request;
	}

	@Override
	public void transaccion() {
		if(transaccion == null)
			transaccion = new Transaccion(request);
		if (request.getMontoActual() >= request.getMontoCompra() ) {
			this.transaccion.transaccion();
		} else {
			System.out.println("No cuenta con los fondos suficientes para realizar la compra.");
		}
		
	}
	
}
